// $(document).ready(function() {

//     var a = $("body")[0].style;
//     $("#colorpicker-event").colorpicker().on("changeColor", function(b) {
//         a.backgroundColor = b.color.toHex()
//     });

// })