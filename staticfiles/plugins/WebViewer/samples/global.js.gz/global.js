/* eslint-disable-next-line no-unused-vars */
function samplesSetup(instance) {
  instance.enableElements(['bookmarksPanel', 'bookmarksPanelButton']);
  instance.enableFeatures([instance.Feature.Measurement]);
}
